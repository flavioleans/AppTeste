package br.applabbs.webappexemplo.Repository

class BancoDadosConstantes {
    object USER{
        val TABLE_NAME = "lista_cidades"

        object COLUMNS {
            val ID = "id"
            val CIDADE = "cidade"
            val ESTADO = "estado"
            val CODIGO = "codigo"
        }
    }
}