package br.applabbs.webappexemplo.Repository

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class BancoDadosHelper (context: Context): SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION){

    companion object{
        private val DATABASE_VERSION: Int = 1
        private val DATABASE_NAME: String = "lista_cidades"
    }

    private val createTable = """ CREATE TABLE ${BancoDadosConstantes.USER.TABLE_NAME}(
        ${BancoDadosConstantes.USER.COLUMNS.ID} INTEGER PRIMARY KEY AUTOINCREMENT,
        ${BancoDadosConstantes.USER.COLUMNS.CIDADE} TEXT,
        ${BancoDadosConstantes.USER.COLUMNS.ESTADO} TEXT,
        ${BancoDadosConstantes.USER.COLUMNS.CODIGO} TEXT
        ); """

    private val deletarCidade = """ 
        UPDATE ${BancoDadosConstantes.USER.TABLE_NAME} 
        SET ${BancoDadosConstantes.USER.COLUMNS.CIDADE} = 
        WHERE ${BancoDadosConstantes.USER.COLUMNS}
        
    """.trimIndent()

    override fun onCreate(sqlLite: SQLiteDatabase) {
        sqlLite.execSQL(createTable)
    }

    override fun onUpgrade(sqlLite: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        sqlLite.execSQL(deletarCidade)
    }
}